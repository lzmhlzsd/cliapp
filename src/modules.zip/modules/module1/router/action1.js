import Main from './../../../components/spIndex.vue'
export default [
    // 销售
    {
        path: '/module1Action1',
        /*

        */
        name: 'module1Action1',
        component: Main,
        children: [
            {
                path: '/',
                redirect: 'List1'
            },
            {
                path: 'List1',
                title: 'List1',
                name: 'List1',
                component: resolve => require.ensure( [], () => resolve( require( './../views/action1/List1' ) ), /* 模块名-菜单名-子菜单名 */ 'module1-action1-List1' )
            },
            {
                path: 'List2',
                title: 'List2',
                name: 'List2',
                component: resolve => require.ensure( [], () => resolve( require( './../views/action1/List2' ) ), /* 模块名-菜单名-子菜单名 */ 'module1-action1-List2' )
            }
        ]
    },
    {
        path: '/',
        redirect: '/module1Action1/List1'
    }
]

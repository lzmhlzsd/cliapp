export default {
    modulename: 'module1',
    baseUrl: '/api',
    auth: 'lkj',
    datetime: '2018-11-21'
}

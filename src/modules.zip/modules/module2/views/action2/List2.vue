<template>
  <div>
      this is module1-action2-list2
  </div>
</template>

<script>
export default {
    data () {
        return {

        }
    },
    computed: {},
    created () {},
    mounted () {},
    watch: {},
    methods: {}
}
</script>

<style lang="less" scoped>
</style>

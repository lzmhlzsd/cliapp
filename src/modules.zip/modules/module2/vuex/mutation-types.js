/*
    motation命名：模块名 + GET/SET + method
*/
export const MODULE1_SET_DATA = 'MODULE1_SET_DATA'

export default {
    modulename: 'module2',
    baseUrl: '/api',
    auth: 'lkj',
    datetime: '2018-11-21'
}

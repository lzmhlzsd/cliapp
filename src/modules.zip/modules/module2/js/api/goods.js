import fetch from './../../../../libs/fetch'
import moduleInfo from './../../module.info'
// 商品列表
const goodsList = params =>
    fetch( moduleInfo.baseUrl + '/ecstorex/goodsList', params, 'POST' )
export default {
    goodsList
}

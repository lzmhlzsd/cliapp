import action1 from './action1'
import action2 from './action2'

const router = [].concat( action1, action2 )
export default router

import Main from './../../../components/spIndex.vue'
export default [
    // 登录页面
    {
        path: '/module2Action2',
        name: 'module2Action2',
        component: Main,
        children: [
            {
                path: '/',
                redirect: 'List1'
            },
            {
                path: 'List1',
                title: 'List1',
                name: 'List1',
                component: resolve => require.ensure( [], () => resolve( require( './../views/action2/List1' ) ), /* 模块名-菜单名-子菜单名 */'module2-action2-List1' )
            },
            {
                path: 'List2',
                title: 'List2',
                name: 'List2',
                component: resolve => require.ensure( [], () => resolve( require( './../views/action2/List2' ) ), /* 模块名-菜单名-子菜单名 */'module2-action2-List2' )
            }
        ]
    }
]
